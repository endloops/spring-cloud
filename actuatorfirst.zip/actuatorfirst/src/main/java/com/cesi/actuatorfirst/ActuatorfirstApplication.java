package com.cesi.actuatorfirst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActuatorfirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActuatorfirstApplication.class, args);
	}
}
