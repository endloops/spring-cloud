package com.example.ceshi.wszuul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WszuulApplication {

	public static void main(String[] args) {
		SpringApplication.run(WszuulApplication.class, args);
	}
}
