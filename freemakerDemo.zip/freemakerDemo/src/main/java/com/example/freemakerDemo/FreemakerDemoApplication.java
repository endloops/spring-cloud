package com.example.freemakerDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreemakerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreemakerDemoApplication.class, args);
	}
}
